<h1>
  Blender script
</h1>

> Project status: Under development

This Blender script was created in order to facilitate our control of blender objects. I big problem I came across when I started to try to modifie objects in blender
through python commands was the name of its functions, how way that its classes works. So I decided to create this to help using python commands in blender.

It is necessary to have some packages installed
```
  pip install bpy math numpy pandas sympy sqlite3
```
